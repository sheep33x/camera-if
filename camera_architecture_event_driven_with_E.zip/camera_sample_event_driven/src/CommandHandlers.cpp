#include "CommandHandlers.hpp"
#include <utility>
class AHandler final : public ICommandHandler {
public: using ICommandHandler::ICommandHandler;
    void start() override {dispatch_({Action::Kind::ApplyConfig,req_.id,req_.cameraId});}
    void onEvent(const Event& e) override {if(e.type==EventType::ConfigDone)send("A completed");}
};
class BHandler final : public ICommandHandler {
    enum class Stage{Config,Capture,StartingReceive,WaitingImage} stage_=Stage::Config;
public: using ICommandHandler::ICommandHandler;
    void start() override {dispatch_({Action::Kind::ApplyConfig,req_.id,req_.cameraId});}
    void onEvent(const Event& e) override {
        if(stage_==Stage::Config && e.type==EventType::ConfigDone) {
            stage_=Stage::Capture;dispatch_({Action::Kind::StartCapture,req_.id,req_.cameraId});
        } else if(stage_==Stage::Capture && e.type==EventType::CaptureStarted) {
            stage_=Stage::StartingReceive;dispatch_({Action::Kind::StartReceive,req_.id,req_.cameraId});
        } else if(stage_==Stage::StartingReceive && e.type==EventType::ReceiveStarted) {
            stage_=Stage::WaitingImage;
        } else if(stage_==Stage::WaitingImage && e.type==EventType::ImageArrived) send("B image received");
    }
};
class CHandler final : public ICommandHandler {
public: using ICommandHandler::ICommandHandler;
    void start() override {dispatch_({Action::Kind::StopReceive,req_.id,req_.cameraId});}
    void onEvent(const Event& e) override {if(e.type==EventType::ReceiveStopped)send("C receive stopped");}
};
class DHandler final : public ICommandHandler {
public: using ICommandHandler::ICommandHandler;
    void start() override {
        dispatch_({req_.dOperation==DOperation::Start?Action::Kind::StartWrite:Action::Kind::QueryWrite,req_.id,req_.cameraId});
    }
    void onEvent(const Event& e) override {
        if(req_.dOperation==DOperation::Start && e.type==EventType::WriteAccepted)send("D accepted (camera still writing)");
        if(req_.dOperation==DOperation::Query && e.type==EventType::WriteStatus)
            send(e.writeState==WriteState::Writing?"D writing":e.writeState==WriteState::Complete?"D complete":"D none/error");
    }
};
class EHandler final : public ICommandHandler {
    enum class Stage{ReadingRegister,StartingReceive,WaitingImage} stage_=Stage::ReadingRegister;
    uint32_t registerValue_=0;
public: using ICommandHandler::ICommandHandler;
    void start() override {dispatch_({Action::Kind::ReadRegister,req_.id,req_.cameraId});}
    void onEvent(const Event& e) override {
        if(stage_==Stage::ReadingRegister && e.type==EventType::RegisterRead) {
            registerValue_=e.registerValue;
            stage_=Stage::StartingReceive;
            dispatch_({Action::Kind::StartReceive,req_.id,req_.cameraId,registerValue_});
        } else if(stage_==Stage::StartingReceive && e.type==EventType::ReceiveStarted) {
            stage_=Stage::WaitingImage;
        } else if(stage_==Stage::WaitingImage && e.type==EventType::ImageArrived) send("E image received, parameter="+std::to_string(registerValue_));
    }
};
std::unique_ptr<ICommandHandler> makeHandler(Request r,Dispatch d,Respond out) {
    switch(r.command) {
    case Command::A:return std::make_unique<AHandler>(r,d,out);
    case Command::B:return std::make_unique<BHandler>(r,d,out);
    case Command::C:return std::make_unique<CHandler>(r,d,out);
    case Command::D:return std::make_unique<DHandler>(r,d,out);
    case Command::E:return std::make_unique<EHandler>(r,d,out);
    }
    return {};
}
