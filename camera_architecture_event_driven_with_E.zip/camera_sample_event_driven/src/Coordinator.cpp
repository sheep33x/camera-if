#include "Coordinator.hpp"
#include <iostream>
#include <type_traits>
void Coordinator::addCamera(int id,std::unique_ptr<CameraModelStrategy> model) {
    cameras_[id]=std::make_unique<CameraScheduler>(id,std::move(model),[this](Event e){postEvent(e);});
}
void Coordinator::startHandler(const Request& r) {
    auto dispatch=[this](Action a){cameras_.at(a.cameraId)->dispatch(a);};
    auto respond=[](const Request& request,const std::string& result) {
        std::cout << "[response route=" << request.responseRoute << " request=" << request.id << "] " << result << '\n';
    };
    auto handler=makeHandler(r,dispatch,respond);
    handlers_[r.id]=std::move(handler);
    handlers_.at(r.id)->start();
}
void Coordinator::tryStartNext(int cameraId) {
    auto& scheduler=*cameras_.at(cameraId);
    if(stopping_.count(cameraId) || scheduler.hasActive() || !scheduler.hasPending()) return;
    Request r=scheduler.startNext();
    if(r.command==Command::B || r.command==Command::E) activeReceive_[cameraId]=r.id;
    startHandler(r);
}
void Coordinator::finishHandler(uint64_t id,int cameraId) {
    handlers_.erase(id);
    auto receive=activeReceive_.find(cameraId);
    if(receive!=activeReceive_.end() && receive->second==id) activeReceive_.erase(receive);
    cameras_.at(cameraId)->finish(id);
    tryStartNext(cameraId);
}
void Coordinator::onRequest(const Request& r) {
    if(!cameras_.count(r.cameraId)) {std::cout << "unknown camera\n";return;}
    if(handlers_.count(r.id)) {std::cout << "duplicate request ID\n";return;}
    if(r.command==Command::C) {
        // Cだけ通常FIFOを通さない。受信停止が確定するまでは次の通常コマンドを開始しない。
        if(stopping_.count(r.cameraId)) {std::cout << "stop already pending\n";return;}
        stopping_[r.cameraId]=r.id;
        startHandler(r);
        return;
    }
    cameras_.at(r.cameraId)->enqueue(r);
    tryStartNext(r.cameraId);
}
void Coordinator::onEvent(const Event& e) {
    auto it=handlers_.find(e.requestId);
    if(it==handlers_.end()) return; // 古いイベントやキャンセル済みイベントを無視
    it->second->onEvent(e);
    if(!it->second->finished()) return;
    const bool wasStop=(stopping_.count(e.cameraId) && stopping_.at(e.cameraId)==e.requestId);
    if(wasStop && e.type==EventType::ReceiveStopped) {
        stopping_.erase(e.cameraId);
        // 停止確認後に受信待ちのB/Eをキャンセル。古い画像イベントは破棄する。
        auto active=activeReceive_.find(e.cameraId);
        if(active!=activeReceive_.end()) {
            const uint64_t victim=active->second;
            auto victimHandler=handlers_.find(victim);
            if(victimHandler!=handlers_.end()) victimHandler->second->cancel();
            finishHandler(victim,e.cameraId);
        }
    }
    finishHandler(e.requestId,e.cameraId);
}
void Coordinator::run() {
    while(running_) {
        CoordinatorMessage msg=inbox_.pop();
        std::visit([this](auto&& value){
            using T=std::decay_t<decltype(value)>;
            if constexpr(std::is_same_v<T,Request>) onRequest(value);
            else if constexpr(std::is_same_v<T,Event>) onEvent(value);
            else if constexpr(std::is_same_v<T,ImageNotification>) {
                auto it=activeReceive_.find(value.cameraId);
                if(it!=activeReceive_.end() && it->second==value.requestId)
                    onEvent({value.requestId,value.cameraId,EventType::ImageArrived});
            } else if constexpr(std::is_same_v<T,Shutdown>) running_=false;
        },msg);
    }
}
