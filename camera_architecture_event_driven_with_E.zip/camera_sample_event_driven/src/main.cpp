#include "Coordinator.hpp"
#include <chrono>
#include <memory>
#include <thread>
// 通信A/Bの代わりにpostRequestを呼ぶ。SDKコールバックの代わりにpostImageを呼ぶ。
int main() {
    Coordinator coordinator;
    coordinator.addCamera(1,std::make_unique<ModelAStrategy>());
    coordinator.addCamera(2,std::make_unique<ModelBStrategy>());
    std::thread coordinatorThread([&]{coordinator.run();});
    coordinator.postRequest({100,1,Command::E,"route-A"});
    coordinator.postRequest({101,1,Command::A,"route-B"}); // Eが画像を受け取るまでキューで待機
    coordinator.postRequest({200,2,Command::B,"route-B"}); // カメラ2は並列
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    coordinator.postImage(1,100); // Eの画像受信を擬似通知
    coordinator.postImage(2,200); // Bの画像受信を擬似通知
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    coordinator.postRequest({102,1,Command::B,"route-A"});
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    coordinator.postRequest({103,1,Command::C,"route-B"}); // B受信待ちを中断
    coordinator.postRequest({201,2,Command::D,"route-A",DOperation::Start});
    coordinator.postRequest({202,2,Command::D,"route-A",DOperation::Query});
    std::this_thread::sleep_for(std::chrono::milliseconds(150));
    coordinator.stop();
    coordinatorThread.join();
}
