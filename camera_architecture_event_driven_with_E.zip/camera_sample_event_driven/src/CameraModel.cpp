#include "CameraModel.hpp"
#include <string>
void ModelAStrategy::applyConfig(ControlSdkHandle& sdk) const {
    RegisterMap r{0x100,0x104,0x108,0x10c};
    sdk.perform("WriteReg(exposure="+std::to_string(r.exposure)+")");
    sdk.perform("WriteReg(gain="+std::to_string(r.gain)+")");
}
void ModelAStrategy::startCapture(ControlSdkHandle& sdk) const {
    sdk.perform("WriteReg(trigger) -> SDK.StartCapture()");
}
uint32_t ModelAStrategy::readImageParameter(ControlSdkHandle& sdk) const {
    return sdk.readReg(0x10c);
}
void ModelBStrategy::applyConfig(ControlSdkHandle& sdk) const {
    RegisterMap r{0x200,0x210,0x220,0x224};
    sdk.perform("SDK.SetMode()");
    sdk.perform("WriteReg(gain="+std::to_string(r.gain)+")");
    sdk.perform("WriteReg(exposure="+std::to_string(r.exposure)+")");
}
void ModelBStrategy::startCapture(ControlSdkHandle& sdk) const {
    sdk.perform("SDK.PrepareCapture() -> SDK.StartCapture()");
}
uint32_t ModelBStrategy::readImageParameter(ControlSdkHandle& sdk) const {
    return sdk.readReg(0x224)*2; // 機種固有の値変換例
}
