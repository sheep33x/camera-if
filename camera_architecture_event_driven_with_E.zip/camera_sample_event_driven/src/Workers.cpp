#include "Workers.hpp"
#include <utility>
ControlWorker::ControlWorker(int id, std::unique_ptr<CameraModelStrategy> model, std::function<void(Event)> emit)
    : model_(std::move(model)),emit_(std::move(emit)),thread_([this,id]{run(id);}) {}
ControlWorker::~ControlWorker() { tasks_.push(WorkerShutdown{}); if(thread_.joinable()) thread_.join(); }
void ControlWorker::run(int cameraId) {
    ControlSdkHandle sdk(cameraId); // 制御スレッドでのみ生成・使用
    WriteState writeState = WriteState::None;
    for (;;) {
        auto message=tasks_.pop();
        if(std::holds_alternative<WorkerShutdown>(message)) break;
        const auto a=std::get<Action>(message);
        switch(a.kind) {
        case Action::Kind::ApplyConfig:
            model_->applyConfig(sdk); emit_({a.requestId,cameraId,EventType::ConfigDone}); break;
        case Action::Kind::StartCapture:
            model_->startCapture(sdk); emit_({a.requestId,cameraId,EventType::CaptureStarted}); break;
        case Action::Kind::ReadRegister:
            emit_({a.requestId,cameraId,EventType::RegisterRead,model_->readImageParameter(sdk)}); break;
        case Action::Kind::StartWrite:
            sdk.perform("SDK.BeginMemoryWrite()"); writeState=WriteState::Writing;
            emit_({a.requestId,cameraId,EventType::WriteAccepted,0,writeState}); break;
        case Action::Kind::QueryWrite:
            sdk.perform("SDK.QueryMemoryWrite()");
            emit_({a.requestId,cameraId,EventType::WriteStatus,0,writeState}); break;
        default: break;
        }
    }
}
ReceiveWorker::ReceiveWorker(int id, std::function<void(Event)> emit)
    : emit_(std::move(emit)),thread_([this,id]{run(id);}) {}
ReceiveWorker::~ReceiveWorker() { tasks_.push(WorkerShutdown{}); if(thread_.joinable()) thread_.join(); }
void ReceiveWorker::run(int cameraId) {
    ReceiveSdkHandle sdk(cameraId); // 受信スレッドでのみ生成・使用
    uint64_t receivingRequest=0;
    for (;;) {
        auto message=tasks_.pop();
        if(std::holds_alternative<WorkerShutdown>(message)) break;
        const auto a=std::get<Action>(message);
        if(a.kind==Action::Kind::StartReceive) {
            receivingRequest=a.requestId;
            sdk.start(a.parameter); // 非ブロッキング開始APIを想定
            emit_({a.requestId,cameraId,EventType::ReceiveStarted});
            // 実SDKでは画像コールバックをEventに変換。デモではCoordinator::postImageで代用。
        } else if(a.kind==Action::Kind::StopReceive) {
            sdk.stop(); receivingRequest=0;
            emit_({a.requestId,cameraId,EventType::ReceiveStopped});
        }
    }
}
