# カメラ制御イベント駆動サンプル（C++17）

以前の `camera_architecture_dummy_sample.zip` をベースに、**コマンドEとカメラごとのイベント駆動Scheduler**を追加した構成例です。通信部分と実際のSDKは実装せず、SDKハンドルを模したクラスを用います。

## ファイル構成

```text
camera_sample_event_driven/
├── include/
│   ├── Types.hpp             # Request / Action / Event / Eの読み込み値
│   ├── ThreadQueue.hpp       # スレッド間メッセージキュー
│   ├── DummySdk.hpp          # 制御/受信用ダミーSDKハンドル
│   ├── CameraModel.hpp       # ModelA/BのStrategy
│   ├── Workers.hpp           # 制御/受信Worker
│   ├── CameraScheduler.hpp   # カメラ単位のFIFO・実行権
│   ├── CommandHandlers.hpp   # Handlerインターフェース
│   └── Coordinator.hpp       # 要求とイベントのルーティング
├── src/
│   ├── CameraModel.cpp
│   ├── Workers.cpp
│   ├── CommandHandlers.cpp   # A/B/C/D/Eの状態遷移
│   ├── Coordinator.cpp       # スケジューリング、Cの停止確認
│   └── main.cpp              # 2カメラの擬似シナリオ
└── CMakeLists.txt
```

## イベント駆動の動き

1. `Coordinator::onRequest` が通常コマンドをカメラ別 `CameraScheduler` のFIFOに追加します。
2. 空いているカメラでは `tryStartNext()` が1つだけHandlerを開始します。
3. Handlerは `Action` を `ControlWorker` または `ReceiveWorker` に投入し、**待機せず戻ります**。
4. WorkerはそれぞれのスレッドでSDKハンドルを使用し、完了を `Event` としてCoordinatorに送ります。
5. Coordinatorが対象Handlerの `onEvent` を呼び、次のActionへ進めます。
6. Handlerが完了するとSchedulerの実行権を解放し、次の通常コマンドを開始します。

### Eの例（カメラ1）

```text
E開始（Scheduler.active=E）
  -> ControlWorker: ReadRegister
  <- RegisterRead(value=...)
  -> ReceiveWorker: StartReceive(value)
  <- ReceiveStarted
  ... 画像受信待ち（Coordinatorも制御Workerもブロックしない）
  <- ImageArrived
E完了 -> Scheduler.activeを解放 -> 待っていたAを開始
```

**Eのレジスタ読み込みから画像受信完了まで、カメラ1の通常コマンドA/B/Dは開始しません。** ただしカメラ2の処理は並行して進みます。

### Cによる割り込み

Cは通常FIFOを通さず、受信Workerに `StopReceive` を投入します。`ReceiveStopped` イベントが戻ったら、進行中のB/Eにキャンセル応答を返して実行権を解放します。停止確認前に次の通常コマンドを開始しないよう `stopping_` で制御します。

※ このデモは**非ブロッキングの受信開始API**を前提にしています。受信Worker自身がブロッキング受信APIで塞がるSDKなら、タイムアウト付き受信やSDKが許す別経路キャンセルが必要です。

### Dの扱い

`DOperation::Start` と `DOperation::Query` をリクエストで区別します（以前のID偶奇判定は廃止）。開始要求は受付完了イベントで応答して実行権を解放します。カメラ内部の書き込み状態はControlWorker側に残り、Queryで照会します。**書き込み中のA/B/Eの可否判定は未実装**で、実機仕様に応じたカメラ状態ガードが必要です。

## このサンプルの割り切り

- 通信・実SDK・SDKコールバック・画像バッファ処理はダミーです。`main.cpp`の `postImage(cameraId,requestId)` が画像到着の代用です。
- SDKハンドルは各Workerの `run()` 内で生成・使用し、別スレッドから直接触れません。
- SchedulerのFIFOとHandler状態はCoordinatorスレッドからのみ変更します。
- Cの競合（受信開始前にCが来た場合、Cの連続投入など）、遅延イベント、切断、タイムアウト、SDKエラー、厳密な書き込み中制限は簡略化しています。特に**Cが受信開始Actionより先に停止処理される競合**は実製品では停止対象のフェーズ管理が必要です。
- これは構成理解用で、製品品質・実機動作は保証しません。

## 参考ビルド方法（必須ではありません）

```sh
cmake -S . -B build
cmake --build build
```
