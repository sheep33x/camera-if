#pragma once
#include "Types.hpp"
#include "ThreadQueue.hpp"
#include "CameraModel.hpp"
#include <functional>
#include <memory>
#include <thread>
#include <variant>
struct WorkerShutdown {};
using WorkerMessage = std::variant<Action, WorkerShutdown>;
class ControlWorker {
    ThreadQueue<WorkerMessage> tasks_;
    std::thread thread_;
    std::unique_ptr<CameraModelStrategy> model_;
    std::function<void(Event)> emit_;
    void run(int cameraId);
public:
    ControlWorker(int id, std::unique_ptr<CameraModelStrategy> model, std::function<void(Event)> emit);
    ~ControlWorker();
    void post(Action action) { tasks_.push(action); }
};
class ReceiveWorker {
    ThreadQueue<WorkerMessage> tasks_;
    std::thread thread_;
    std::function<void(Event)> emit_;
    void run(int cameraId);
public:
    ReceiveWorker(int id, std::function<void(Event)> emit);
    ~ReceiveWorker();
    void post(Action action) { tasks_.push(action); }
};
