#pragma once
#include "CameraScheduler.hpp"
#include "CommandHandlers.hpp"
#include "ThreadQueue.hpp"
#include <map>
#include <memory>
#include <variant>
struct ImageNotification {int cameraId;uint64_t requestId;};
struct Shutdown {};
using CoordinatorMessage=std::variant<Request,Event,ImageNotification,Shutdown>;
class Coordinator {
    ThreadQueue<CoordinatorMessage> inbox_;
    std::map<int,std::unique_ptr<CameraScheduler>> cameras_;
    std::map<uint64_t,std::unique_ptr<ICommandHandler>> handlers_;
    std::map<int,uint64_t> activeReceive_;
    std::map<int,uint64_t> stopping_; // C完了まで通常コマンド開始を保留
    bool running_=true;
    void startHandler(const Request& request);
    void tryStartNext(int cameraId);
    void finishHandler(uint64_t requestId,int cameraId);
    void onRequest(const Request&);
    void onEvent(const Event&);
public:
    void addCamera(int id,std::unique_ptr<CameraModelStrategy> model);
    void postRequest(Request r){inbox_.push(std::move(r));}
    void postEvent(Event e){inbox_.push(e);}
    void postImage(int cameraId,uint64_t requestId){inbox_.push(ImageNotification{cameraId,requestId});}
    void stop(){inbox_.push(Shutdown{});}
    void run(); // Coordinatorスレッドで実行。Workerの完了はイベントで受ける。
};
