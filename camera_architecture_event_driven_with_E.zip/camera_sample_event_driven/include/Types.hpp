#pragma once
#include <cstdint>
#include <string>

enum class Command { A, B, C, D, E };
enum class DOperation { Start, Query };
enum class EventType { ConfigDone, CaptureStarted, RegisterRead, ReceiveStarted, ImageArrived, ReceiveStopped, WriteAccepted, WriteStatus, Failed };
enum class WriteState { None, Writing, Complete, Error };
struct Request {
    uint64_t id;
    int cameraId;
    Command command;
    std::string responseRoute;
    DOperation dOperation = DOperation::Start;
};
struct Event {
    uint64_t requestId;
    int cameraId;
    EventType type;
    uint32_t registerValue = 0;
    WriteState writeState = WriteState::None;
};
struct Action {
    enum class Kind { ApplyConfig, StartCapture, ReadRegister, StartReceive, StopReceive, StartWrite, QueryWrite } kind;
    uint64_t requestId;
    int cameraId;
    uint32_t parameter = 0;
};
