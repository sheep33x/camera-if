#pragma once
#include "DummySdk.hpp"
#include <cstdint>
struct RegisterMap { uint32_t exposure; uint32_t gain; uint32_t trigger; uint32_t imageParameter; };
// 大きなコマンド手順は共通。機種固有のSDK API選択・順序・レジスタのみここに置く。
class CameraModelStrategy {
public:
    virtual ~CameraModelStrategy() = default;
    virtual void applyConfig(ControlSdkHandle&) const = 0;
    virtual void startCapture(ControlSdkHandle&) const = 0;
    virtual uint32_t readImageParameter(ControlSdkHandle&) const = 0;
};
class ModelAStrategy final : public CameraModelStrategy {
public:
    void applyConfig(ControlSdkHandle&) const override;
    void startCapture(ControlSdkHandle&) const override;
    uint32_t readImageParameter(ControlSdkHandle&) const override;
};
class ModelBStrategy final : public CameraModelStrategy {
public:
    void applyConfig(ControlSdkHandle&) const override;
    void startCapture(ControlSdkHandle&) const override;
    uint32_t readImageParameter(ControlSdkHandle&) const override;
};
