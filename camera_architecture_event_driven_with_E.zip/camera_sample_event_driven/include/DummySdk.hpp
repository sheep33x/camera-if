#pragma once
#include <cstdint>
#include <iostream>
#include <string>
// 説明用。SDKハンドルは、それぞれの所有Workerスレッド内で生成する。
class ControlSdkHandle {
    int cameraId_;
public:
    explicit ControlSdkHandle(int id):cameraId_(id){}
    void perform(const std::string& description) { std::cout << "[control SDK camera=" << cameraId_ << "] " << description << '\n'; }
    uint32_t readReg(uint32_t address) {
        std::cout << "[control SDK camera=" << cameraId_ << "] ReadReg(" << address << ")\n";
        return address + 10; // ダミー値
    }
};
class ReceiveSdkHandle {
    int cameraId_;
public:
    explicit ReceiveSdkHandle(int id):cameraId_(id){}
    void start(uint32_t value) { std::cout << "[receive SDK camera=" << cameraId_ << "] StartReceive(value=" << value << ")\n"; }
    void stop() { std::cout << "[receive SDK camera=" << cameraId_ << "] StopReceive()\n"; }
};
