#pragma once
#include "Workers.hpp"
#include <functional>
#include <memory>
#include <optional>
#include <queue>
// Coordinatorスレッドのみからアクセスする。通常コマンドを1件ずつ開始する。
class CameraScheduler {
    int cameraId_;
    ControlWorker control_;
    ReceiveWorker receive_;
    std::queue<Request> pending_;
    std::optional<uint64_t> active_;
public:
    CameraScheduler(int id,std::unique_ptr<CameraModelStrategy> model,std::function<void(Event)> emit)
        :cameraId_(id),control_(id,std::move(model),emit),receive_(id,emit){}
    void enqueue(Request r) { pending_.push(std::move(r)); }
    bool hasActive() const { return active_.has_value(); }
    bool hasPending() const { return !pending_.empty(); }
    Request startNext() {
        Request r=pending_.front(); pending_.pop(); active_=r.id; return r;
    }
    void finish(uint64_t requestId) {
        if(active_ && *active_==requestId) active_.reset();
    }
    std::optional<uint64_t> activeRequest() const { return active_; }
    void dispatch(Action a) {
        if(a.kind==Action::Kind::StartReceive || a.kind==Action::Kind::StopReceive) receive_.post(a);
        else control_.post(a);
    }
};
