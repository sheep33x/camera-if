cmake_minimum_required(VERSION 3.12)
project(camera_sample_event_driven LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
find_package(Threads REQUIRED)
add_executable(camera_sample
    src/main.cpp src/Coordinator.cpp src/CommandHandlers.cpp
    src/Workers.cpp src/CameraModel.cpp)
target_include_directories(camera_sample PRIVATE include)
target_link_libraries(camera_sample PRIVATE Threads::Threads)
